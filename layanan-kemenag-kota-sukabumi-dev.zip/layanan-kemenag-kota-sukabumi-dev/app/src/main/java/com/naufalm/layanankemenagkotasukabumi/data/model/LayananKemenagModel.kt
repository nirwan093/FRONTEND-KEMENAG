package com.naufalm.layanankemenagkotasukabumi.data.model

data class LayananKemenag(
    val kemenagProfile: List<String>,
    val hajjInfo: String,
    val bimasInfo: String,
    val pontrenInfo: List<String>,
    val penmadInfo: List<String>,
    val zakatInfo: List<String>,
    val paiInfo: List<String>,
    val subbagTuInfo: List<String>
)